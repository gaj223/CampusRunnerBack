<?php
$basedir = realpath(__DIR__);
?>